export enum QueryToken {
    Now = "Now",
    Today = "Today",
    UserID = "UserID"
}