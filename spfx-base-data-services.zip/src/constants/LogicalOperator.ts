export enum LogicalOperator {
    And = "And",
    Or = "Or"
}