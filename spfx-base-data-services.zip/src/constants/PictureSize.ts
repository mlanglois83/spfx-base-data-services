/**
 * Picture sizes for users photo
 */
export enum PictureSize {
    Small = "S",
    Medium = "M",
    Large = "L",
}