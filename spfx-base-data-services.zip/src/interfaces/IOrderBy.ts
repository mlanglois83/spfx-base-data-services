export interface IOrderBy {
    type: "orderby";
    propertyName: string;
    ascending?: boolean;
}