export interface ISynchronizationEnded {
    errors: string[];
}