/**
 * Transaction types used by transactions and synchronization service
 */
export enum TransactionType {
    AddOrUpdate = "AddOrUpdate",
    Delete = "Delete"
}