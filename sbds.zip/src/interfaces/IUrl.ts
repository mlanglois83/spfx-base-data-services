export interface IUrl {
    url: string;
    description?: string;
}